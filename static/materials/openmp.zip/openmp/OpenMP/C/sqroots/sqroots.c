/*
  ! Demonstrates the simple use of parallel
  ! regions on an array of square roots
*/

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>
#include <omp.h>

int main()
{
  long number_of_threads=1,thread_number=0,average,from,to,i,maximum;
  double sum, *sqrs;
/*  printf("The maximum integer please: \n"); */
  scanf("%ld",&maximum);
  sqrs=(double*)malloc((maximum+1)*sizeof(double));
#pragma omp parallel shared(sqrs,maximum) private(number_of_threads,thread_number,average,from,to,i) 
  {
    number_of_threads=omp_get_num_threads();
    thread_number=omp_get_thread_num();
    average=maximum/number_of_threads + 1;
    from=thread_number*average;
    to=(thread_number+1)*average - 1;
    if(to > maximum) to = maximum;
    for(i=from;i<=to;i++){sqrs[i]=(double)sqrt((float)i);}
  }
  sum=0.0;
  for(i=0;i<=maximum;i++) sum=sum+sqrs[i];
  free(sqrs);
  printf(" Result = %f \n", sum);
  return 0;
}

