#include <stdio.h>
#include <math.h>
#include <omp.h>
#include <stdlib.h>
#include <unistd.h>

unsigned int sleep(unsigned int);
double dpow(double a,int b){int i;double c=1;for(i=0;i<b;i++){c*=a;}return c;}

double g(double x,int n){
    /* This function contains a call to sleep
       to simulate time-consuming computations */
    sleep(1); 
    return dpow(x,n);
}

int main(){ 
    /* This program contains a data dependency 
       and a race-condition. Try to remove them
       Hint: pre-calculate pre and have a look at term */
    int i;
    double x,sum=1,pre[21],term;
    printf("X=?: \n");scanf("%lf",&x);
    pre[0]=1;for(i=1;i<21;i++){pre[i]=pre[i-1]/i;}
#pragma omp parallel for reduction(+:sum) private(term)
    for (i=1;i<21;i++){
	term=g(x,i);
	sum+=pre[i]*term;
	printf("nt=%d i=%d pre=%lf term=%lf\n",
	       omp_get_thread_num(),i,pre[i],term);
    }
    printf("Result=%20.16lf\n",sum);
    return 0;
}


