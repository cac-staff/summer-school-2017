/*
  ! Picks out the smallest element of
  ! an array using omp_lock
*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <omp.h>

int main()
{
  int i, n=1000000;
  double array[n], smallest=2.0;
  omp_lock_t lock;

  for(i=0; i<n; i++) array[i]=(double)(rand()+1)*(rand()+2)/((double)RAND_MAX*RAND_MAX);

  omp_init_lock(&lock);
#pragma omp parallel for private(i) shared(array,n,smallest) 
  for(i=0; i<n; i++) 
     {
#ifdef LOCK
      if(smallest > array[i])
        {
	  omp_set_lock(&lock);
#endif
	  if(smallest > array[i]) {smallest = array[i];} 
#ifdef LOCK
	  omp_unset_lock(&lock);
        }
#endif
     }
  omp_destroy_lock(&lock);

  printf(" The smallest of %d elements is %e .\n", n, smallest);
  return 0;
}
