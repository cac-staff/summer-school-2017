#include <stdio.h>
#include <math.h>
#include <omp.h>
int main()
{
  long i,m;
  double d,x,sum=0,p=1.0/sqrt(atan(1.0));
  printf("p=%f\n",p);
  printf("Give the argument x and the number of intervals: \n");
  scanf("%lf %ld",&x,&m);
  d=x/m;
#pragma omp parallel for private(i) shared(m) reduction(+:sum)
  for(i=0;i<=m;i++) sum=sum+exp(-(i*d)*(i*d));
  printf(" Result = %f \n", p*d*sum);
  return 0;
}

