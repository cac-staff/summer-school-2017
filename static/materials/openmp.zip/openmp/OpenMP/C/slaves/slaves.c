/*
  ! all-slave model programmed in OpenMP
  ! getting the job is done sequentially (critical)
  ! executing it is done in parallel
*/


#include <stdio.h>
#include <math.h>
#include <omp.h>
#include <stdlib.h>
#include <unistd.h>

void load();
int get_job();
int do_the_job(int, int);
int work[20];

int main(){
    int my_job, my_thread_num=0;
    load();
#pragma omp parallel private(my_job, my_thread_num) 
    {
	my_thread_num=omp_get_thread_num();
	my_job=get_job();
	while(my_job != 0){
	    do_the_job(my_job, my_thread_num);
	    my_job=get_job();
	}
    }
    return 0;
}

void load(){
    int i,randnum;
    for (i=0;i<20;i++){
        randnum=rand();
	work[i]=randnum-(randnum/5)*5+1;
    }
}

int get_job(){
    static int number_of_jobs=20, job_assigned=0;
    int the_job;
#pragma omp critical 
    {
	if(job_assigned < number_of_jobs){ 
	    job_assigned++;
	    the_job=job_assigned;
	}
	else the_job=0;
    }
    return(the_job);
}

int do_the_job(int my_job, int my_thread_num)
{ /* ! sleep a while, report back */
    int st=work[my_job-1];
    sleep(st);
    printf(" Job number %d done by thread number %d, slept for %d secs.\n", 
	   my_job, my_thread_num, st);
    return 0;
}

