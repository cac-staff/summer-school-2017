/*
C    Copyright (c) 2009-2010 by High Performance Computing Virtual Laboratory
C
C    This is a race condition example between data updating
C    and referencing in OpenMP.
C
C    Here we have total number THE_TOTAL_JOBS of independent
C    jobs to complete. They will be grouped into groups with
C    TOTAL_JOBS_PER_GROUP number of jobs in each group. The
C    computation will be done group by group, and inside each
C    group, the "all-slave" model is used. For every group,
C    the initial data Initial_Data_Of_A_Job_Group array is
C    updated just before the group is being performed. Then
C    a race condition occurs when some elements of the
C    Initial_Data_Of_A_Job_Group array are still needed by one
C    thread for his current job, while another thread finds
C    no more jobs left un-assigned in the current group, and
C    wants to update the Initial_Data_Of_A_Job_Group array
C    for the next job group.
C
C    For a solution, please go to the solution version.
C
C    www.hpcvl.org
C    Copyright (c) 2009-2010 by High Performance Computing Virtual Laboratory
*/


#include <omp.h>
#include <stdio.h>
#include <stdlib.h>

#define THE_TOTAL_JOBS 6007
#define TOTAL_JOBS_PER_GROUP 15

int  Total_Num_of_Groups=(THE_TOTAL_JOBS-1)/TOTAL_JOBS_PER_GROUP+1;
int  Job_Group=0;
int  All_Results[THE_TOTAL_JOBS*2];
int  Initial_Data_For_Jobs[THE_TOTAL_JOBS];
int  Initial_Data_Of_A_Job_Group[TOTAL_JOBS_PER_GROUP];
int  End_Of_Group_Jobs=-100;
int  Job_Assigned=1000, Job_From=100, Job_To=-20;

int  Get_Job();
void Working();
void Do_The_Job(int my_job);
void Prepare_Job_Group_Data();
void Check_Results();


int main()
{ int i;
  for(i=0;i<THE_TOTAL_JOBS;i++)Initial_Data_For_Jobs[i]=i;
#pragma omp parallel default(shared)
      {Working();}
  Check_Results();
}


void Do_The_Job(int my_job)
{ int integer=Initial_Data_Of_A_Job_Group[my_job-
              (my_job/TOTAL_JOBS_PER_GROUP)*TOTAL_JOBS_PER_GROUP];
  All_Results[2*my_job]=integer;
  All_Results[2*my_job+1]=integer*2;
}


void Prepare_Job_Group_Data()
{int i,j=0;
 Job_From=Job_Group*TOTAL_JOBS_PER_GROUP;
 Job_To= Job_From-1+TOTAL_JOBS_PER_GROUP;
 if(THE_TOTAL_JOBS<=Job_To) Job_To=THE_TOTAL_JOBS-1;
 for(i=Job_From;i<=Job_To;i++)
    {Initial_Data_Of_A_Job_Group[j]=Initial_Data_For_Jobs[i];j++;}
}


int Get_Job()
{  int the_job;
   if(Job_Assigned < Job_To)
     {Job_Assigned++;
      the_job=Job_Assigned;
     }
   else the_job=End_Of_Group_Jobs;
   return(the_job);
}


void Working()
{ int repeat=1, my_job;
      while (repeat ==1)
       {
#pragma omp critical (the_only_one_critical)
          {my_job=Get_Job();
           if(my_job == End_Of_Group_Jobs)
             {if (Job_Group < Total_Num_of_Groups)
                 {Prepare_Job_Group_Data();
                  Job_Assigned=Job_From-1;
                  my_job=Get_Job();
                  Job_Group++;
                 }
              else
                 {repeat=0;}
             }
          }
        if(my_job != End_Of_Group_Jobs)
           Do_The_Job(my_job);
       }
}


void Check_Results()
{ int i,j;
  FILE * fout;
  fout=fopen("results.txt","w");
  for(i=0;i<THE_TOTAL_JOBS;i++)
     {j=2*i;
      fprintf(fout," %d %d %d %d %d \n",i,
           Initial_Data_For_Jobs[i],All_Results[j],j,All_Results[j+1]);
      if(i != Initial_Data_For_Jobs[i])
        {fprintf(fout,"Initial Data Error: %d %d %d %d %d \n",i,
           Initial_Data_For_Jobs[i],All_Results[j],j,All_Results[j+1]);
         printf(      "Initial Data Error: %d %d %d %d %d \n",i,
           Initial_Data_For_Jobs[i],All_Results[j],j,All_Results[j+1]);
        }
      if((All_Results[j]*2) != All_Results[j+1])
        {fprintf(fout,"Job Computing Error: %d %d %d %d %d \n",i,
           Initial_Data_For_Jobs[i],All_Results[j],j,All_Results[j+1]);
         printf(      "Job Computing Error: %d %d %d %d %d \n",i,
           Initial_Data_For_Jobs[i],All_Results[j],j,All_Results[j+1]);
        }
      if(i != All_Results[j])
        {fprintf(fout,"Race ???:     %d %d (%d) \n",i,All_Results[j],
                              (All_Results[j]-i)/TOTAL_JOBS_PER_GROUP);
         printf(      "Race ???:     %d %d (%d) \n",i,All_Results[j],
                              (All_Results[j]-i)/TOTAL_JOBS_PER_GROUP);
        }
      if(j != All_Results[j+1])
        {fprintf(fout,"Wrong Result: %d %d %d %d %d (%d) \n",i,
           Initial_Data_For_Jobs[i],All_Results[j],j,All_Results[j+1],
                       (All_Results[j+1]-j)/(2*TOTAL_JOBS_PER_GROUP));
         printf(      "Wrong Result: %d %d %d %d %d (%d) \n",i,
           Initial_Data_For_Jobs[i],All_Results[j],j,All_Results[j+1],
                       (All_Results[j+1]-j)/(2*TOTAL_JOBS_PER_GROUP));
        }
     }
  fprintf(fout," \n");
  fprintf(fout," Total jobs: %d (with %d each group).\n",
                 THE_TOTAL_JOBS, TOTAL_JOBS_PER_GROUP);
  printf(      " Total jobs: %d (with %d each group).\n",
                 THE_TOTAL_JOBS, TOTAL_JOBS_PER_GROUP);
  fclose(fout);
}


