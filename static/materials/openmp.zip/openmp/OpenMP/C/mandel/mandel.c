#include <stdio.h>
#include <math.h>

int set(double,double);

int main(){
    int i,j,m,n,result,count;
    double re,im,dre,dim;
    printf("The maximum integer please: \n");
    scanf("%d %d",&m,&n);
    printf("%d %d \n",m,n);
    dre=0;
    dim=0;
    if (m>0) dre=(double)2/m;
    if (n>0) dim=(double)1/n;
    count=0;
#pragma omp parallel for private(i,j,im,re,result) reduction(+:count) schedule(runtime)
    for(j=0;j<=n;j++){ 
	im=j*dim;
	for(i=0;i<=m;i++){
	    re=i*dre-(double)1.5;
	    result=set(re,im); 
            count=count+result;
	    /* printf(" %d %d %f %f %d\n",i,j,re,im,result); */
			      }
    }
    printf("%d\n",count);
    return count;
}

int set(double re,double im){
    double testr,testi,testrn,testin,test;
    int i,limit=1024,setval;
    setval=1; testr=0; testi=0; testrn=0; testin=0;
    for (i=1;i<=limit;i++){
	testrn=re+testr*testr-testi*testi;
	testin=im+2*testi*testr;
        testr=testrn;
        testi=testin;
	test=testr*testr+testi*testi;
	if (test>(double)4){
	    setval=0;
	    break;
	}
    }
    return setval;
}

