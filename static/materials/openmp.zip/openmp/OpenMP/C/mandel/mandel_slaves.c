#include <stdio.h>
#include <math.h>
#include <omp.h>
#include <stdlib.h>
#include <unistd.h>

int get_job();
int do_the_job(int, int);
int set(double,double);

double re,dre,dim;
int m,n,lcount,count;

int main(){
    int my_job, my_thread_num=0, i;
    printf("The maximum integer please: \n");
    scanf("%d %d",&m,&n);
    dre=0;
    dim=0;
    count=0;
    if (m>0) dre=(double)2/m;
    if (n>0) dim=(double)1/n;    
#pragma omp parallel private(my_job, my_thread_num, lcount) 
    {
	my_thread_num=omp_get_thread_num();
        lcount=0;
	my_job=get_job();
	while(my_job != 0){
	    lcount=lcount+do_the_job(my_job, my_thread_num);
	    my_job=get_job();
	}
#pragma omp critical(COUNT)
    {count=count+lcount;}
    }
    printf("%d\n",count);
    return 0;
}

int get_job(){
    static int job_assigned=0;
    int the_job;
#pragma omp critical 
    {
	if(job_assigned < n+1){ 
	    job_assigned++;
	    the_job=job_assigned;
	}
	else the_job=0;
    }
    return(the_job);
}

int do_the_job(int my_job, int my_thread_num)
{ /* pick an imaginary part and call set() */
    double lim;
    int i,result;
    lim=(my_job-1)*dim;
    result=0;
    for(i=0;i<=m;i++){
	re=i*dre-(double)1.5;
	result=result+set(re,lim);
    }
    /* printf(" Job number %d done by thread number %d, called set with Im(c)= %f result= %d\n", 
           my_job, my_thread_num, lim, result); */
    return result;
}

int set(double re,double im){
    double testr,testi,testrn,testin,test;
    int i,limit=1024,setval;
    setval=1; testr=0; testi=0; testrn=0; testin=0;
    for (i=1;i<=limit;i++){
	testrn=re+testr*testr-testi*testi;
	testin=im+2*testi*testr;
	testr=testrn;
	testi=testin;
	test=testr*testr+testi*testi;
	if (test>(double)4){
	    setval=0;
	    break;
	}
    }
    return setval;
}

