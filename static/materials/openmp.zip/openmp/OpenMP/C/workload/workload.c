#include <stdio.h>
#include <math.h>
#include <omp.h>
#include <stdlib.h>
#include <unistd.h>

unsigned int sleep(unsigned int);

int main()
{
  int i,m;
  float basetime=10.0;
  unsigned int* sleeptime;
  printf("Give the number of random tasks: \n");
  scanf("%d",&m);
  sleeptime=(unsigned int*)malloc(m*sizeof(unsigned int));
  for (i=0;i<m;i++){
      *(sleeptime+i)=1+(unsigned int)(basetime*rand()/RAND_MAX); 
  }
#pragma omp parallel for schedule(runtime)
  for(i=0;i<m;i++){
      printf(" Task #%d Thread %d is sleeping for %d seconds\n",\
	     i+1,omp_get_thread_num(),*(sleeptime+i));
      sleep(*(sleeptime+i));}
}


