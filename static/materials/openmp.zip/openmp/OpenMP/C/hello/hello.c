#include <stdio.h>
#include <omp.h>
int main() 
{
    printf("Here is the main thread (serial) ...\n");
#ifdef _OPENMP
#pragma omp parallel 
    {
      printf(" ... and here is thread number %d %s \n",
               omp_get_thread_num(), "(parallel) ...");
    }
#endif
    printf(" ... and now it is serial again.\n");
    return 0;
}
