/*
C   It performs parallelized calculation of the
C   multiplication of matrix A on matrix B.
C   HPCVL, Queen.s University, October, 2006
*/

#include <stdio.h>
#include <omp.h>
#include <stdlib.h>


int MatrixSize[3];
float *MatrixA, *MatrixB, *MatrixC;


void MatrixInitialize();
void MatrixMultiplication();
void MatrixOutput();
void MatrixFree();


int main()
{
  MatrixInitialize();
  MatrixMultiplication();
  MatrixOutput();
  MatrixFree();
  return 0;
}

void MatrixInitialize()
{
  FILE * fin;
  int i, j;
  fin=fopen("in.dat","r");
  fscanf(fin,"%d %d %d", &MatrixSize[2], &MatrixSize[1], &MatrixSize[0]);
  
  MatrixA=(float *)malloc(MatrixSize[2]*MatrixSize[1]*sizeof(float));
  MatrixB=(float *)malloc(MatrixSize[0]*MatrixSize[1]*sizeof(float));
  MatrixC=(float *)malloc(MatrixSize[2]*MatrixSize[0]*sizeof(float));

  for(i=0;i<MatrixSize[2];i++) for(j=0;j<MatrixSize[1];j++) 
      fscanf(fin,"%f ", &MatrixA[i*MatrixSize[1]+j]); 
  for(i=0;i<MatrixSize[1];i++) for(j=0;j<MatrixSize[0];j++) 
      fscanf(fin,"%f ", &MatrixB[j*MatrixSize[1]+i]); 
  fclose(fin);
}




void MatrixMultiplication()
{
  int i, j, k, A0, B0, C0;
  for(i=0;i<MatrixSize[2]*MatrixSize[0];i++) MatrixC[i]=0.0; 

#pragma omp parallel for private(j,k,A0,B0,C0)
  for(i=0;i<MatrixSize[2];i++) 
     {
      C0=i*MatrixSize[0];
      A0=i*MatrixSize[1];
      for(j=0;j<MatrixSize[0];j++) 
         {
          B0=j*MatrixSize[1];
          for(k=0;k<MatrixSize[1];k++) 
              MatrixC[C0+j]=MatrixC[C0+j]+MatrixA[A0+k]*MatrixB[B0+k];
         }
     }
}




void MatrixOutput()
{
     int i, j;
     FILE * fout;
     fout=fopen("out.dat","w");
        for(i=0;i<MatrixSize[2];i++) 
           {
            for(j=0;j<MatrixSize[0];j++)
                fprintf(fout,"%f %s", MatrixC[i*MatrixSize[0]+j]," ");fprintf(fout,"\n");
           }
     fclose(fout);
}


void MatrixFree()
{ 
     free(MatrixA); 
     free(MatrixB); 
     free(MatrixC); 
}

