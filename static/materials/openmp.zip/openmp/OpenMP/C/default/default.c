#include <stdio.h>
#include <math.h>
#include <omp.h>

int afunct(double *, int *, int*);

int main()
{
    int i,j,k=10;
    double x[k+1];
    for(i=1; i<=k; i++) x[i]=sqrt((double)i);
#pragma omp parallel for private(j) 
    for(i=1; i<=k; i++) 
       { for(j=1; j<=k; j++) afunct(&x[i], &k, &j);
         printf(" %d %d %f \n", omp_get_thread_num(), i, x[i]);
       }
    return(0);
}

int afunct(double * a, int * in, int * index)
{
    int isub;
    double b=0.23;
    for(isub=1; isub<=*index; isub++) *a=*a+sqrt(*in+isub+b);
    return(0);
}


