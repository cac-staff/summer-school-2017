#include <stdio.h>
#include <math.h>
int main()
{
  long int i,m;
  double sum, t1, t2;
  printf("The maximum integer please: \n");
  scanf("%ld",&m);
  sum=0.0;
#pragma omp parallel for private(i) shared(m) reduction(+:sum)
    for(i=0;i<=m;i++) sum=sum+sqrt((double)i);
  printf(" Result = %f \n", sum);
  return 0;
}
