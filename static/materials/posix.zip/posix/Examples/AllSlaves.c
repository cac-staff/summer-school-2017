#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "pthread.h"

/*
  ! all-slave model programmed using Posix threads
  ! getting the job is done sequentially (mutex protected)
  ! executing it is done in parallel
*/


struct SubTask
{
    int thread_id;
};


void *DoJobs(void *arg);
int DoJob(int Job, int Thread);
int GetJob();

int main(int argc, char *argv[])
{
	int id,nt=atoi(argv[1]);
	pthread_t thread[nt];
	struct SubTask SubTasks[nt];
	
	for (id=0;id<nt;id++)
	    {
		SubTasks[id].thread_id=id;
		pthread_create(&thread[id], NULL, DoJobs, (void*)&SubTasks[id]);
	    }
	for (id=0;id<nt;id++){
	    pthread_join(thread[id], NULL);
	}
	printf("All Jobs Done\n");
}

void *DoJobs(void *arg)
{
    int MyThread,MyJob;
    double MySum;
    struct SubTask *MyTask;

    MyTask=(struct SubTask*) arg;
    MyThread=MyTask->thread_id;
    MyJob=GetJob(); 
    while(MyJob != 0)
	{
	    DoJob(MyJob, MyThread);
	    MyJob=GetJob();
	}
    pthread_exit(NULL);
}

int DoJob(int Job, int Thread)
/* ! do senseless busy-work, report back */
{
  double x=1.0;
  int i;
  for(i=1;i<=10000000;i++) x=sqrt(log(x+Job));
  printf(" Job number %d done by thread number %d, result = %f .\n",
                                          Job, Thread, x);
  return 0;
}

int GetJob()
{
    static int JobsTotal=20, JobsAssigned=0;
    static pthread_mutex_t CountJob=PTHREAD_MUTEX_INITIALIZER;  
    int ThisJob;
    pthread_mutex_lock(&CountJob);
    if(JobsAssigned < JobsTotal)
	{
	    JobsAssigned++;
	    ThisJob=JobsAssigned;
	}
    else ThisJob=0;
    pthread_mutex_unlock(&CountJob);
    return(ThisJob);
}
