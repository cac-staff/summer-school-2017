/* Sample routine for demsonstration of Mutex Initialization using pthread_once 
 * Hartmut Schmider, 2009, based on Butenhof p.133  */

#include <pthread.h>
#include <stdio.h>
#include <errno.h>

int counter=0;								/* counter is shared and needs protecting */
pthread_mutex_t mutex;						/* mutex is used to protect counter */
pthread_once_t blocker=PTHREAD_ONCE_INIT;	/* blocker is used to protect mutex */

void *startup (void *arg);

int main (int argc, char *argv[]){
    pthread_t thread[100];
    int status, id;
	/* 100 threads created and waited for */
	for (id=0;id<100;id++) status = pthread_create(&thread[id],NULL,startup,NULL);
    for (id=0;id<100;id++) status = pthread_join(thread[id],NULL);
	printf ("%d\n",counter);				/* counter should be 100 */
    return status;
}

void mutex_init(){
	int status;
	status=pthread_mutex_init(&mutex, NULL); /* Dynamic Mutex Initialization */
}

void *startup (void *arg){
	int status;
	status=pthread_once (&blocker,mutex_init);	/* blocker makes sure mutex_init is called
												 * only once, even for multiple threads */
	status=pthread_mutex_lock (&mutex);			/* Locking ... */
	counter++;
	status=pthread_mutex_unlock (&mutex);		/* ... and unlocking mutex to protect update */
	pthread_exit(NULL);
}

