#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void *word(void *arg);

int main(){
    pthread_t first, second;
    pthread_create(&first, NULL,word,(void*)"Hello");
    pthread_create(&second, NULL,word,(void*)"World\n");
    pthread_join (first,NULL);
    pthread_join (second,NULL);
    exit(0);
}

void *word(void *arg){
	printf("%s ",(char*)arg);
	return(0);
}
