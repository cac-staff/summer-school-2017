#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
	
struct SubTask
{ /** data structure to pass input and output arguments **/
    int thread_id;
    int max_int;
    int num_tasks;
    double partial_sum;
};

void *PartSum(void *arg); /** routine and argument needs to be void **/

int main(int argc, char *argv[]){ 
	/** main routine createsht reads and computes total sum **/
	int id,rv,nt=atoi(argv[1]),m=atoi(argv[2]);
	double TotalSum;
	pthread_t thread[nt];        /** array of threads **/
	struct SubTask SubTasks[nt]; /** array of argument structures **/

	for (id=0;id<nt;id++){ 
		/** load each structure with proper info **/
		SubTasks[id].thread_id=id;
		SubTasks[id].max_int=m;
		SubTasks[id].num_tasks=nt;
		SubTasks[id].partial_sum=0;
		/** create thread, recasting structure pointer to void **/
		pthread_create(&thread[id], NULL, PartSum, (void*)&SubTasks[id]); 
	    }
	TotalSum=0;
	for (id=0;id<nt;id++){						/** compute total sum **/
		pthread_join(thread[id], NULL);			/** wait for thread **/
	    TotalSum += SubTasks[id].partial_sum;	/** add partial sum to total **/
	}
	printf("Total Sum is %10.5f\n",TotalSum);
}

void *PartSum(void *arg)
{ /** compute each partial sum on different thread **/
    int MyThread,MyMax,MyJump,il;
    double MySum;
    struct SubTask *MyTask;

    MyTask=(struct SubTask*) arg; /** convert void pointer backk to structure **/
    MyThread=MyTask->thread_id;
    MyMax=MyTask->max_int;
    MyJump=MyTask->num_tasks;     /** sum proceeds in steps of number of threads **/
    MySum=MyTask->partial_sum;

    for (il=MyThread;il<MyMax+1;il=il+MyJump) 
	{ /** partial sum **/
	    MySum += sqrt((double)il);
	}
    printf("Partial Sum on Thread Number %d is %10.5f \n",MyThread,MySum);
    MyTask->partial_sum=MySum;
    pthread_exit(NULL);
}
