#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

/* Demo program for TSD destructors
   Based on Butenhof p.169
   Hartmut Schmider Oct 2009 */

int counter=0;				/* Counts threads */
pthread_key_t key;			/* TSD key */
pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER; /* mutex to protect counter */

void destruct(void *arg);	/* Destructor function */
void *startup (void *arg);	/* Startup function    */
void *get_key(void);		/* Allocating some data to a key */

typedef struct TSD_t{		/* Structure contains thread ID and a message */
	pthread_t thread;		
	char *message;} tsd_t;	/* The message will be allocated on the heap */

int main (int argc, char *argv[]){
	int i, rc;
	pthread_t one,two;		/* Two threads */
	tsd_t *tsd;				/* TSD for master */
	
	pthread_key_create(&key,destruct);	/* Making key and associating destructor */
	counter=0;							/* Initialize thread counter */

	tsd=(tsd_t*)get_key();				/* Load TSD structure for master */
	tsd->thread = pthread_self();
	tsd->message = "This is the Master Thread";
	printf ("%s just getting started\n",tsd->message);

	pthread_create(&one,NULL,startup,"This is Thread One");	/* Create threads */
	pthread_create(&two,NULL,startup,"This is Thread Two");
	pthread_exit(NULL);										/* Done, no join */
}

void *startup (void *arg){	/* Startup function only loads TSD for threads ... */
	tsd_t *MyTSD = (tsd_t*)get_key();
	MyTSD->thread=pthread_self();
	MyTSD->message=(char*)arg;
	printf ("%s just getting started\n",MyTSD->message);
	sleep(2);				/* ... sleeps a while ... */
	pthread_exit(NULL);		/* ... and terminates the thread */
}

void *get_key(void){		/* Used to allocate space for TSD and associate key */
	void *gotit;
	gotit=pthread_getspecific(key);					/* See if data are there */
	if (gotit==NULL){								/* If not ... */
		gotit=malloc(sizeof(tsd_t));				/* ...allocate space ... */
		pthread_setspecific(key,(void*)gotit);		/* ...and set key */
		printf("Allocating TSD structure\n");
	}
	return gotit;									/* return pointer points to TSD */
}						

void destruct(void *arg){	/* Cleans up after thread that used TSD quits */
	tsd_t *TSD=(tsd_t*)arg;
	printf("%s calling it quits \n",TSD->message);	/* Print message (still there!) */
	free(arg);										/* Free space (avoid leaks)     */
	pthread_mutex_lock(&mutex);						/* Protect counter				*/
	counter++;
	if (counter>=3){								/* If all thread are done ...	*/
		pthread_key_delete(key);					/* Delete the key				*/
		printf("Just deleted the key\n");
	}
	pthread_mutex_unlock(&mutex);					/* Release lock					*/
}

