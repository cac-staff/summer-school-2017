/*  TSDhard.c
 *  Created by Hartmut Schmider on 18/10/09.
 *  Copyright 2009 Hartmut Schmider. All rights reserved.
 */
#include <pthread.h>
#include <stdio.h>
#include <errno.h>

void *tsd_routine (void *arg);
void dump (void *fors);
pthread_key_t key;							/* globally declare key */
pthread_once_t once = PTHREAD_ONCE_INIT;	/* used to protect key creation */

void init_key(void){ /* initializes TSD key */
	pthread_key_create(&key,NULL);
}

int main (int argc, char *argv[]){
	pthread_t one, two; /* declare two threads */
	int error;
	/* create both threads, then wait for them */
	pthread_create(&one,NULL,tsd_routine,"First thread"); 
	pthread_create(&two,NULL,tsd_routine,"Second thread"); 
	pthread_join(one,NULL); pthread_join(two,NULL);
	return 0;
}	

void *tsd_routine (void *arg){
	char *message, *output;
	int error;
	pthread_once(&once,init_key);			/* init_key is only called once */
	message=(char*)arg;						/* receive message */
	pthread_setspecific(key,message);		/* use pthread_setspecific to set (private) value of key */
	dump("First");							/* Call to dump retrieves data once... */
	sleep(2);                               /* ...wait ...*/
	dump("Second");							/* ...and again */
	pthread_exit(NULL);
}

void dump(void *fors){ /* Demonstrates that key stays persistent across function calls */
	char *output;
	char *ForS=(char *)fors;
	output=(char*)pthread_getspecific(key); /* retrieve message from key ... */
	printf("%s %s output\n",output,ForS);	/* ...print it out with argument...*/
}
