#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

int main (int argc, char *argv[]){
	int n;
	double t1=atof(argv[1]),tinf=atof(argv[2]);
	double sinf,finf,en,sn,tn;
	sinf=t1/tinf; finf=1.0/sinf;
	printf("Serial time %f, limit time %f\n",t1,tinf);
	printf("limit speedup %f, serial fraction %f\n",sinf,finf);
	for (n=1;n<65;n++){
		sn=1.0/(finf+(1.0-finf)/n);
		tn=t1/sn;
		en=sn/n;
		printf("%d %f %f %f\n",n,tn/t1,sn,en);}
 }
