/*
  ! Demonstrates the use of a barrier
*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void *Barrier(void *arg);
pthread_barrier_t barrier;

int main(int argc, char *argv[])
{
    unsigned id,nt=atoi(argv[1]);
    pthread_t thread[nt];

	pthread_barrier_init(&barrier,NULL,nt);
    /* Generating Threads */
    for (id=0;id<nt;id++){
	    pthread_create(&thread[id], NULL, Barrier, (void*)id);}
    
    for (id=0;id<nt;id++){pthread_join(thread[id], NULL);}
	pthread_barrier_destroy(&barrier);
    exit(0);
}

void *Barrier(void *arg)
{
    int Thread = (int)arg;

    printf("Thread Number %d starting first task\n",Thread);
	sleep(Thread+1);
    printf("Thread Number %d finished first task\n",Thread);
    printf("Thread Number %d calling barrier\n",Thread);
	
	pthread_barrier_wait(&barrier);
    
    printf("Thread Number %d starting second task\n",Thread);
	sleep(1);
    printf("Thread Number %d finished second task\n",Thread);
}

