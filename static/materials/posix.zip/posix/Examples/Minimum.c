/*
  ! Picks out the smallest element of
  ! an array overlaid on a function on the domain [-1,1]
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>

struct SubTask
{
    int thread_id;
    int min_int;
    int max_int;
};

void *PartLoop(void *arg);
double f(double x);

double SmallestValue, MinimumAt, Step;
int m;

int main(int argc, char *argv[])
{
    int id,nt=atoi(argv[1]),m=atoi(argv[2]),width=(m-1)/nt+1;
    int min_num, max_num;
    pthread_t thread[nt];
    struct SubTask SubTasks[nt];

    Step=2.0/m;
    MinimumAt=1.0;
    SmallestValue=f(MinimumAt);
    

    /* Generating Threads */
    for (id=0;id<nt;id++)
	{
	    min_num=id*width;
	    max_num=(id+1)*width-1;
	    if (max_num > (m-1)) max_num=m-1;
	    SubTasks[id].thread_id=id;
	    SubTasks[id].min_int=min_num;
	    SubTasks[id].max_int=max_num;
	    pthread_create(&thread[id], NULL, PartLoop, (void*)&SubTasks[id]);
	}
    
    for (id=0;id<nt;id++)
	{
	    pthread_join(thread[id], NULL);
	}

    printf(" The smallest of %d values is %18.15f at %18.15f\n", m, SmallestValue,MinimumAt);
    exit(0);
}

void *PartLoop(void *arg)
{
    int MyThread, MyMin, MyMax, i;
    static pthread_mutex_t Update=PTHREAD_MUTEX_INITIALIZER;  
    double MyCoord,MyValue;
    struct SubTask *MyTask;

    MyTask=(struct SubTask*) arg;
    MyThread=MyTask->thread_id;
    MyMin=MyTask->min_int;
    MyMax=MyTask->max_int;
    
    printf("Thread Number %d checking elements %d to %d\n",MyThread,MyMin,MyMax);
    
    for(i=MyMin; i<MyMax+1; i++) 
	{
	    MyCoord=i*Step-1.0;
	    MyValue=f(MyCoord);
	    if(MyValue < SmallestValue)
		{
		    pthread_mutex_lock(&Update);
		    if(MyValue < SmallestValue)
			{ 		    
			    MinimumAt=MyCoord;
			    SmallestValue=MyValue;
			}
		    pthread_mutex_unlock(&Update); 
		}
	}
}

double f(double x)
{
    return x*x+1;
}
