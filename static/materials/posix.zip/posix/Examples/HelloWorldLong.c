#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void *output(void *arg);
int nt;

int main(int argc, char *argv[]){
   long id,ids[nt];
   nt=atoi(argv[1]);
   pthread_t thread[nt];
   void* thread_return;
   for (id=0;id<nt;id++){
      ids[id]=id;
      pthread_create(&thread[id], NULL, output, (void*)ids[id]);
   }
   for (id=0;id<nt;id++){ 
      pthread_join(thread[id],&thread_return);
      printf("%s on thread %ld\n",(char *)thread_return,id);
   }
   return 0;
}

void *output(void *arg){
    long tid=(long)arg;
    printf("Hello from thread Number %ld of %d\n",tid,nt);
    return(&"Normal Return");
}
