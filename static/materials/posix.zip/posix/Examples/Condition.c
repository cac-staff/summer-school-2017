#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

int counter=0;
pthread_mutex_t mutex;
pthread_cond_t cv;

void *counting(void *arg){ /* Counts up to 12, then signals waiting thread */
	int i;
	long id=(long)arg;
	for (i=0; i<10; i++){
		pthread_mutex_lock(&mutex);
		counter++;
		if (counter==12){
			pthread_cond_signal(&cv);
			printf("Thread %ld (counter=%d) reached threshold\n", id, counter);
			}
		pthread_mutex_unlock(&mutex);
		printf("Thread %ld (counter=%d) unlocked mutex\n", id, counter);
		sleep(1);
		}
	pthread_exit(NULL);
}

void *waiting(void *arg){ /* Waits for count 12, then adds 100 */
	long id = (long)arg;
	printf("Thread %ld starts watching\n", id);
	pthread_mutex_lock(&mutex);
	if (counter<12){
		pthread_cond_wait(&cv,&mutex);
		printf("Thread %ld received signal\n", id);
		counter += 100;
		printf("Thread %ld counted up to %d\n", id, counter);
    }
	pthread_mutex_unlock(&mutex);
	pthread_exit(NULL);
}

int main (int argc, char *argv[]){
  int i, rc;
  pthread_t threads[3];
  pthread_mutex_init(&mutex, NULL);
  pthread_cond_init (&cv, NULL);
  pthread_create(&threads[0],NULL, waiting,  (void *)1);
  pthread_create(&threads[1],NULL, counting, (void *)2);
  pthread_create(&threads[2],NULL, counting, (void *)3);
  for (i=0; i<3; i++) {pthread_join(threads[i], NULL);}
  printf ("All threads are in\n");
  pthread_mutex_destroy(&mutex);
  pthread_cond_destroy(&cv);
  pthread_exit(NULL);
}
