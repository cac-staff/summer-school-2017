#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

/*   Example program based on Blase Barney's (Lawrence Livermore National Lab) 
 example in https://computing.llnl.gov/tutorials/pthreads */

struct Vector{ /* Needed data are in a global structure */
	double   *A, *B;
	double	AdotB; 
	int		Length, NumThreads; 
	pthread_mutex_t SumMutex;
};
struct Vector vector;

/* Define startup function and a mutex */
void *DotProduct(void *arg);

int main (int argc, char *argv[]){
	long i;
	double *a, *b;
	void *status;
	int nt=atoi(argv[1]),nv=atoi(argv[2]);
	pthread_t Threads[nt]; /* Defining thread array */
	
	/* Assign storage and initialize values */
	a = (double*)malloc(nv*sizeof(double));
	b = (double*)malloc(nv*sizeof(double));
	
	for (i=0; i<nv; i++){ /* Fill vectors */
		a[i]=1.0; b[i]=1.0;
    }
	
	vector.Length = nv; /* Load structure */
	vector.A = a; 
	vector.B = b; 
	vector.AdotB = 0.0;
	vector.NumThreads = nt;
	pthread_mutex_init(&vector.SumMutex,NULL); /* Initialize mutex for use in DotProduct */
	
	for(i=0; i<nt; i++){ /* Create all threads */
		pthread_create(&Threads[i], NULL, DotProduct, (void *)i);
	}	
	for(i=0; i<nt; i++){ /* Wait for threads */
		pthread_join(Threads[i], &status);
	}	
	
	printf ("Sum =  %f \n", vector.AdotB); /* Output and cleanup */
	free(a); free(b); pthread_mutex_destroy(&vector.SumMutex);
	pthread_exit(NULL);
}   


void *DotProduct(void *arg){ /* All work is done in this startup function */
	int i, istart, iend, local_length ;
	long local_offset;
	double local_sum, *local_a, *local_b;

	local_offset = (long)arg; /* Thread number serves as offset */ 
	local_length = (vector.Length-1)/vector.NumThreads+1; /* Chunk size chosen almost evenly */
	istart = local_offset*local_length;
	iend = istart+local_length;
	if (iend>vector.Length) iend=vector.Length; /* If last piece is too long, cut it */
	local_a = vector.A;
	local_b = vector.B;

	local_sum = 0;
	for (i=istart; i<iend ; i++){ /* Local sum is generated */
      local_sum += local_a[i]*local_b[i];
    }

	/* When local sums are added up, a mutex needs to protect the total */
   pthread_mutex_lock(&vector.SumMutex);
   vector.AdotB += local_sum;
   pthread_mutex_unlock(&vector.SumMutex);
   pthread_exit((void*) 0);
}


