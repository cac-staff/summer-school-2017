#include "stdio.h"
#include "math.h"
#include "mpi.h"
#include "omp.h"

void initialmpi(int *myid, int *totps);

int main(argc,argv)
int argc;
char *argv[];
{
  int myid, totps, i, terms;
  double mys,s;

  MPI_Init(&argc,&argv);
  initialmpi(&myid, &totps);
  if(myid == 0) {
    printf("How many terms?\n");
    scanf("%d",&terms); };
  MPI_Bcast(&terms, 1, MPI_INT, 0,MPI_COMM_WORLD);

  mys=0.0;
#pragma omp parallel for private(i) shared(myid,terms,totps) \
  reduction(+:mys)
  for(i=myid;i<=terms;i=i+totps) {
/*           printf("%d %d %d %d %d %d .\n",terms,totps,
             myid,omp_get_num_threads(),omp_get_thread_num(),i); */
      mys=mys+sqrt((double)i);}

  printf("My portion: %f  of rank: %d . Total terms: %d .\n",
                                             mys,myid,terms);
  s=0.0;
  MPI_Reduce(&mys,&s,1,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);
  if(myid == 0) printf("Total     : %f .\n",s);

  MPI_Finalize();
}

void initialmpi(int *myid, int *totps){
  MPI_Comm_rank(MPI_COMM_WORLD, myid);
  MPI_Comm_size(MPI_COMM_WORLD, totps);}


