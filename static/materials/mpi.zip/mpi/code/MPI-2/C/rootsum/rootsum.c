#include <stdio.h>
#include <math.h>
#include <mpi.h>
#include <time.h>

#define BILLION 1000000000L

void initialmpi(int *myid, int *totps);

int main(argc,argv) int argc; char *argv[];
{
    int myid, totps; 
    long int i, terms;
    double mys,s;
    struct timespec t1,t2;
    MPI_Init(&argc,&argv);
    initialmpi(&myid, &totps);
    if(myid == 0) {
	clock_gettime(CLOCK_REALTIME,&t1);
	printf("How many terms?\n");
	scanf("%ld",&terms); 
    };
    MPI_Bcast(&terms, 1, MPI_LONG, 0,MPI_COMM_WORLD);
    
    mys=0.0;
    for(i=myid;i<=terms;i=i+totps) mys=mys+sqrt((double)i);
    printf("My portion: %f  of rank: %d . Total terms: %ld .\n",mys,myid,terms);
    s=0.0;
    MPI_Reduce(&mys,&s,1,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);
    if(myid == 0) {
	printf("Total     : %f .\n",s);
	clock_gettime(CLOCK_REALTIME,&t2);
	printf("Total time on rank 0 : %6.3f\n",(double)(t2.tv_sec-t1.tv_sec)+(double)(t2.tv_nsec-t1.tv_nsec)/BILLION);
    }
    
    MPI_Finalize();
    exit(0);
}

void initialmpi(int *myid, int *totps)
{
    MPI_Comm_rank(MPI_COMM_WORLD, myid);
    MPI_Comm_size(MPI_COMM_WORLD, totps);
}

