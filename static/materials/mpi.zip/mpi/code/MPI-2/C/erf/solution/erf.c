#include <stdio.h>
#include <math.h>
#include <mpi.h>

void initialmpi(int *myid, int *totps);

int main(argc,argv) int argc; char *argv[];
{
    int myid, totps; 
    long int i, terms;
    double d,mys,x,s,p=1.0/sqrt(atan(1.0));
    MPI_Init(&argc,&argv);
    initialmpi(&myid, &totps);
    if(myid == 0) {
	printf("Argument and how many terms?\n");
	scanf("%lf %ld",&x,&terms); };
    MPI_Bcast(&terms, 1, MPI_LONG, 0,MPI_COMM_WORLD);
    MPI_Bcast(&x, 1, MPI_DOUBLE, 0,MPI_COMM_WORLD);
    
    d=x/terms;
    mys=0.0;
    for(i=myid;i<=terms;i=i+totps) mys=mys+exp(-(i*d)*(i*d));
    printf("My portion: %lf  of rank: %d . Total terms: %ld .\n",mys,myid,terms);
    s=0.0;
    MPI_Reduce(&mys,&s,1,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);
    if(myid == 0) {
	printf("Total     : %lf .\n",p*d*s);
    }
    
    MPI_Finalize();
    exit(0);
}

void initialmpi(int *myid, int *totps)
{
    MPI_Comm_rank(MPI_COMM_WORLD, myid);
    MPI_Comm_size(MPI_COMM_WORLD, totps);
}

