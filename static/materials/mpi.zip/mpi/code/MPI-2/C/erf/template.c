#include <stdio.h>
#include <math.h>
#include <mpi.h>
#include <time.h>

int main()
{ 
    /** Write a small parallel routine that computes the
        'error function' erf at a positive value x by simple
        rectangle rule.
        erf(x)  = 2/sqrt(pi) Int[0,x] e^{-x^2} dx
	= 2d/sqrt(pi) Sum[i=0,m] e^{-xi^2}
        with d=x/m and xi=i*d
    **/ 
}

