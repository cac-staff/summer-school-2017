/*
! This is an example code for user-defined
! data types.
! HPCVL, Queen's University, 2006
*/

#include   <mpi.h>
#include <stdio.h>

int myid, totps;
FILE* fout;
char filename[128];

void test4();

int main(argc,argv)
int argc;
char *argv[];
{
  MPI_Init(&argc,&argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &myid);
  MPI_Comm_size(MPI_COMM_WORLD, &totps);
  test4();
  MPI_Finalize();
  return(0);
}

void test4()
{
#define RL_SIZE 5
#define BLOCK_SIZE 3
#define ARRAY_SIZE 5
 
  struct a_type
    { int in;
      float rl[RL_SIZE];
      double dp;
    } ARRAY[ARRAY_SIZE];

  MPI_Datatype new_real;
  MPI_Datatype new_a_type;
  MPI_Datatype new_a_type_sized;

  int lenth[BLOCK_SIZE];
  MPI_Aint dist[BLOCK_SIZE];
  MPI_Datatype types[BLOCK_SIZE];
 
  MPI_Aint init, finl, intv;
  int i, j, rank;
 
/*
  ! Informing MPI the true elemental size of the 
  ! float :: rl[:] array, in case it is allocated 
  ! differenctly from MPI_FLOAT by the compiler.
*/
  MPI_Get_address(&ARRAY[0].rl[0],&init);
  MPI_Get_address(&ARRAY[0].rl[1],&finl);
  intv=finl-init;
  MPI_Type_create_resized(MPI_FLOAT, 0, intv, &new_real);
  MPI_Type_commit(&new_real);
 
/*
  ! Constructing an MPI datatype new_a_type for 
  ! the ARRAY.
*/
  lenth[0]=1;
  lenth[1]=RL_SIZE;
  lenth[2]=1;
  types[0]=MPI_INT;
  types[1]=new_real;
  types[2]=MPI_DOUBLE;
  MPI_Get_address(&ARRAY[0].in,    &dist[0]);
  MPI_Get_address(&ARRAY[0].rl[0], &dist[1]);
  MPI_Get_address(&ARRAY[0].dp,    &dist[2]);
  dist[2]=dist[2]-dist[0];
  dist[1]=dist[1]-dist[0];
  dist[0]=0;
 
  MPI_Type_create_struct(BLOCK_SIZE,lenth,dist,types,&new_a_type);
  MPI_Type_commit(&new_a_type);
 
/*
  ! Informing MPI the true elemental size of the 
  ! MPI datatype new_a_type, in case it is made 
  ! different by the compiler from MPI thought.
*/
  MPI_Get_address(&ARRAY[0].in, &init);
  MPI_Get_address(&ARRAY[1].in, &finl);
  intv=finl-init;
 
  MPI_Type_create_resized(new_a_type, 0, intv, &new_a_type_sized);
  MPI_Type_commit(&new_a_type_sized);
 
/*
  ! For testing, assign different values to 
  ! ARRAYs among different processes, then
  ! broadcast, and check them.
*/

  sprintf(filename,"out.%d",myid);
  fout = fopen(filename,"w");

  fprintf(fout,"\n Rank %d :\n Before Broadcast ------------------------\n",myid);
  MPI_Barrier(MPI_COMM_WORLD);
  for(i=0; i<ARRAY_SIZE; i++){
      if(myid==0) {
	  ARRAY[i].in=i+1;
	  ARRAY[i].dp=(i+1)*10.0;
	  for(j=0; j<RL_SIZE; j++) ARRAY[i].rl[j]=j+1+(i+1)*100+0.8;
      } else {
	  ARRAY[i].in=-1;
	  ARRAY[i].dp=-1.0;
	  for(j=0; j<RL_SIZE; j++) ARRAY[i].rl[j]=-1.0;
      }
      fprintf(fout,"%d ", ARRAY[i].in);
      for(j=0; j<RL_SIZE; j++) fprintf(fout,"%5.1f ", ARRAY[i].rl[j]);
      fprintf(fout,"%5.1f on rank %d \n", ARRAY[i].dp, myid); 
  }

  MPI_Barrier(MPI_COMM_WORLD);
  MPI_Bcast(&ARRAY[0].in,ARRAY_SIZE,new_a_type_sized,0,MPI_COMM_WORLD);
  MPI_Barrier(MPI_COMM_WORLD);
  
  fprintf(fout," After Broadcast ------------------------\n");
  for(i=0; i<ARRAY_SIZE; i++){
      fprintf(fout,"%d ", ARRAY[i].in);
      for(j=0; j<RL_SIZE; j++) fprintf(fout,"%5.1f ", ARRAY[i].rl[j]);
      fprintf(fout,"%5.1f on rank %d \n", ARRAY[i].dp, myid);
  }

  fclose(fout);
  MPI_Type_free(&new_real        );
  MPI_Type_free(&new_a_type      );
  MPI_Type_free(&new_a_type_sized);
}
