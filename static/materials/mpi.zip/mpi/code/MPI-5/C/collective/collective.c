#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <malloc.h>
#include <time.h>
#include "mpi.h"

#define BILLION 1000000000L
#define NANO 0.000000001
#define FILESIZE 1048576
#define INTS_PER_BLK 16

/* Demonstrating Collective IO based on Using MPI-2 p.65, Fig.3.7 */

int rank, size;

int main(int argc, char**argv){

    MPI_Datatype ftype, etype=MPI_INT;

    MPI_File file;
    MPI_Offset offset;

    int i,nints,*buf,nbuf;
    struct timespec t1,t2;
  
    MPI_Init(&argc,&argv);
    MPI_Comm_size(MPI_COMM_WORLD,&size);
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);

    nbuf=FILESIZE/size;
    buf=(int*)malloc(nbuf);
    nints=nbuf/sizeof(int);

    for (i=0;i<nints;i++) buf[i]=nints*rank+i;

    /* writing 4 times (mem/disk and ind/col) */
    /* creating a 'vector' non-contiguous datatype and committing it */
    MPI_Type_vector(nints/INTS_PER_BLK, INTS_PER_BLK, INTS_PER_BLK*size, MPI_INT, &ftype);
    MPI_Type_commit(&ftype);
    offset=INTS_PER_BLK*sizeof(int)*rank;

    /* 1. Independently to memory */
    MPI_File_open(MPI_COMM_WORLD, "/tmp/dump.dat", MPI_MODE_DELETE_ON_CLOSE|MPI_MODE_CREATE|MPI_MODE_WRONLY, 
	MPI_INFO_NULL, &file);
    MPI_File_set_view(file,offset,etype,ftype,"native",MPI_INFO_NULL);
    clock_gettime(CLOCK_REALTIME,&t1);
    MPI_File_write(file, buf, nints, MPI_INT, MPI_STATUS_IGNORE);
    clock_gettime(CLOCK_REALTIME,&t2);
    MPI_File_close(&file);
    printf("Time for dumping data = %f on rank %d (individual, memory)\n",
        (double)(t2.tv_sec-t1.tv_sec)+(double)(t2.tv_nsec-t1.tv_nsec)/BILLION, rank);
    MPI_Barrier(MPI_COMM_WORLD);

    /* 2. Collectively to memory */
    MPI_File_open(MPI_COMM_WORLD, "/tmp/dump.dat", MPI_MODE_DELETE_ON_CLOSE|MPI_MODE_CREATE|MPI_MODE_WRONLY, 
	MPI_INFO_NULL, &file);
    MPI_File_set_view(file,offset,etype,ftype,"native",MPI_INFO_NULL);
    clock_gettime(CLOCK_REALTIME,&t1);
    MPI_File_write_all(file, buf, nints, MPI_INT, MPI_STATUS_IGNORE);
    clock_gettime(CLOCK_REALTIME,&t2);
    MPI_File_close(&file);
    printf("Time for dumping data = %f on rank %d (collective, memory)\n",
        (double)(t2.tv_nsec-t1.tv_nsec)/BILLION, rank);
    MPI_Barrier(MPI_COMM_WORLD);

    /* 3. Independently to disk */
    MPI_File_open(MPI_COMM_WORLD, "dump.dat", MPI_MODE_DELETE_ON_CLOSE|MPI_MODE_CREATE|MPI_MODE_WRONLY, 
	MPI_INFO_NULL, &file);
    MPI_File_set_view(file,offset,etype,ftype,"native",MPI_INFO_NULL);
    clock_gettime(CLOCK_REALTIME,&t1);
    MPI_File_write(file, buf, nints, MPI_INT, MPI_STATUS_IGNORE);
    clock_gettime(CLOCK_REALTIME,&t2);
    MPI_File_close(&file);
    printf("Time for dumping data = %f on rank %d (individual, disk)  \n",
        (double)(t2.tv_nsec-t1.tv_nsec)/BILLION, rank);
    MPI_Barrier(MPI_COMM_WORLD);

    /* 4. Collectively to memory */
    MPI_File_open(MPI_COMM_WORLD, "dump.dat", MPI_MODE_DELETE_ON_CLOSE|MPI_MODE_CREATE|MPI_MODE_WRONLY, 
	MPI_INFO_NULL, &file);
    MPI_File_set_view(file,offset,etype,ftype,"native",MPI_INFO_NULL);
    clock_gettime(CLOCK_REALTIME,&t1);
    MPI_File_write_all(file, buf, nints, MPI_INT, MPI_STATUS_IGNORE);
    clock_gettime(CLOCK_REALTIME,&t2);
    MPI_File_close(&file);
    printf("Time for dumping data = %f on rank %d (collective, disk)  \n",
        (double)(t2.tv_nsec-t1.tv_nsec)/BILLION, rank);
    /* wrap it up */
    free(buf);
    MPI_Finalize();
}

