#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <malloc.h>
#include <time.h>
#include "mpi.h"

int rank, size;

int main(int argc, char**argv){

    MPI_Datatype contig, ftype, etype=MPI_INT;
    MPI_Aint extent=sizeof(int)*8;

    MPI_File file;
    MPI_Offset offset;

    int i,irank,*buf,nbuf=20;

    MPI_Init(&argc,&argv);
    MPI_Comm_size(MPI_COMM_WORLD,&size);
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);

    buf=(int*)malloc(nbuf*sizeof(int));

    for (i=0;i<nbuf;i++) buf[i]=nbuf*rank+i;

    /* writing */
    MPI_File_open(MPI_COMM_WORLD, "outin.dat", MPI_MODE_CREATE|MPI_MODE_WRONLY, MPI_INFO_NULL, &file);
    /* creating a datatype with two integers and a 'hole' of 6 integers */
    MPI_Type_contiguous(2,etype,&contig);
    MPI_Type_create_resized(contig,0,extent,&ftype);
    MPI_Type_commit(&ftype);
    /* the actual write is non-contiguous using the new datatype */
    offset=rank*2*sizeof(int);
    MPI_File_set_view(file,offset,etype,ftype,"native",MPI_INFO_NULL);
    MPI_File_write(file, buf, nbuf, MPI_INT, MPI_STATUS_IGNORE);
    /* closing the file and syncing after write is done */
    MPI_File_close(&file);
    MPI_Barrier(MPI_COMM_WORLD);
    
    /* reading */
    MPI_File_open(MPI_COMM_WORLD, "outin.dat", MPI_MODE_RDONLY, MPI_INFO_NULL, &file);
    /* the read is contiguous, 'scrambling' the data */
    offset=nbuf*sizeof(int)*rank;
    MPI_File_set_view(file,offset,MPI_INT,MPI_INT,"native",MPI_INFO_NULL);
    MPI_File_read(file, buf, nbuf, MPI_INT, MPI_STATUS_IGNORE);
    MPI_File_close(&file);

    /* output to see the result (force order) */
    for (irank=0;irank<size;irank++){
	MPI_Barrier(MPI_COMM_WORLD);
	if (irank==rank) 
	    for (i=0;i<nbuf;i++) printf(" Process # %d Element %d = %d \n",rank,i,buf[i]);
	MPI_Barrier(MPI_COMM_WORLD);
    }

    /* wrap it up */
    MPI_Type_free(&ftype);
    MPI_Finalize();
}

