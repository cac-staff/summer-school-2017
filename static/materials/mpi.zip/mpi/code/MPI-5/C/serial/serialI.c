#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <malloc.h>
#include <time.h>
#include "mpi.h"

#define BILLION 1000000000L

int rank,size;

void compute(double *array, long array_size, double *ave, double *std, long tot, int r);

int main(int argc,char **argv){
    /* Serial input through read on rank 0 and MPI_Scatter()
       Hartmut Schmider September 2013 */
    FILE * in;
    double *haul, *stuff; 
    double sum,average,diff, standard;
    long ndata,nmax,i,j;
    struct timespec t1,t2;

    MPI_Init(NULL,NULL);  
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
    MPI_Comm_size(MPI_COMM_WORLD,&size);

    /* Read in data */
    if(rank==0){
        clock_gettime(CLOCK_REALTIME,&t1);
	in=fopen("/tmp/c.11","r"); fscanf(in,"%ld\n",&ndata); printf("ndata=%ld\n",ndata);fclose(in);
	haul=(double *)malloc(ndata*sizeof(double));
	in=fopen("/tmp/c.10","r"); fread(haul,sizeof(double),ndata,in); fclose(in);
        clock_gettime(CLOCK_REALTIME,&t2);
	printf("Time for reading data = %f\n",(double)(t2.tv_sec-t1.tv_sec)+(double)(t2.tv_nsec-t1.tv_nsec)/BILLION);
    }

    /* Broadcasting size, scatter data */
    MPI_Bcast(&ndata,1,MPI_LONG,0,MPI_COMM_WORLD);
    nmax=ndata/size;
    stuff=(double*)malloc(nmax*sizeof(double));
    MPI_Scatter(haul,nmax,MPI_DOUBLE_PRECISION,stuff,nmax,MPI_DOUBLE_PRECISION,0,MPI_COMM_WORLD);
    if (rank==0){
	clock_gettime(CLOCK_REALTIME,&t1);
	printf(" Time for communication = %f\n",(double)(t1.tv_sec-t2.tv_sec)+(double)(t1.tv_nsec-t2.tv_nsec)/BILLION);
    }

    /* Compute Average and STandard Deviation */
    compute(stuff,nmax,&average,&standard,ndata,rank);
    if (rank==0){
	printf("Average = %lf\n",average);
	printf("Standard Deviation = %lf\n",standard);
	clock_gettime(CLOCK_REALTIME,&t2);
	printf(" Time for computation = %f\n",(double)(t2.tv_sec-t1.tv_sec)+(double)(t2.tv_nsec-t1.tv_nsec)/BILLION);
    }
    free(stuff);
    MPI_Finalize();
    exit(0);
}
