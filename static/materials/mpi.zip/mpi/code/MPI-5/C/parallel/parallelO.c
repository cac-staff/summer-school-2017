#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <malloc.h>
#include <time.h>
#include "mpi.h"

#define NANO 0.000000001
#define BILLION 1000000000L

void Random(double *array,long array_size,int r);

int rank,size;

int main(int argc,char **argv){

    /* Output through individual files on rank
       Hartmut Schmider December 2013 */

    FILE * out;
    char filename[128];
    double *stuff; 
    struct timespec t1,t2;

    long ndata,nmax,i,j;
    
    MPI_File handle;
    MPI_Offset offset;
    MPI_Status status;

    MPI_Init(&argc,&argv);  
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
    MPI_Comm_size(MPI_COMM_WORLD,&size);

    if(rank==0){
	printf(" How big should the data be ?\n");
	scanf("%ld",&ndata);
        clock_gettime(CLOCK_REALTIME,&t1);
    }

    /* Broadcasting size, loading elements with random numbers */
    MPI_Bcast(&ndata,1,MPI_LONG,0,MPI_COMM_WORLD);
    nmax=ndata/size;
    if (nmax*size != ndata){printf("%ld is not divisible by %d. Sorry.\n",ndata,size);exit(1);}
    stuff=(double*)malloc(nmax*sizeof(double));
    Random(stuff,nmax,rank);
    MPI_Barrier(MPI_COMM_WORLD);
    if (rank==0){
        clock_gettime(CLOCK_REALTIME,&t2);
	printf(" Time for loading array = %f\n",
            (double)(t2.tv_sec-t1.tv_sec)+(double)(t2.tv_nsec-t1.tv_nsec)/BILLION);
	out=fopen("c.0","w");fprintf(out,"%ld\n",nmax);fclose(out);
    }
    /* Dumping data individually by process (in a sinbgle file) */
    offset=8*rank*nmax;
    MPI_File_open(MPI_COMM_WORLD, "/tmp/c.10", MPI_MODE_CREATE|MPI_MODE_WRONLY, MPI_INFO_NULL, &handle);
    MPI_File_seek(handle, offset, MPI_SEEK_SET);
    MPI_File_write(handle, stuff, nmax, MPI_DOUBLE, &status);
    MPI_File_close(&handle);
    if (rank==0){
        clock_gettime(CLOCK_REALTIME,&t1);
	printf("Time for dumping data = %f\n",
            (double)(t1.tv_sec-t2.tv_sec)+(double)(t1.tv_nsec-t2.tv_nsec)/BILLION);
    }
    free(stuff);
    MPI_Finalize();
    exit(0);
}
