#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <malloc.h>
#include <time.h>
#include "mpi.h"

#define BILLION 1000000000L

void compute(double *array, long array_size, double *ave, double *std, long tot, int r);

int rank,size;

int main(int argc,char **argv){

    /* Input through read from individual files on rank
       Hartmut Schmider December 2013 */

    FILE * in;
    char filename[128];
    double *haul, *stuff; 
    double sum,average,diff, standard;
    long ndata,nmax,i,j;
    struct timespec t1,t2;


    MPI_File handle;
    MPI_Offset offset;
    MPI_Status status;

    MPI_Init(&argc,&argv);  
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
    MPI_Comm_size(MPI_COMM_WORLD,&size);
    
    /* Read in data */
    if(rank==0) {
        clock_gettime(CLOCK_REALTIME,&t1);
	in=fopen("c.0","r");fscanf(in,"%ld",&nmax);fclose(in);
    } 
    MPI_Bcast(&nmax,1,MPI_LONG,0,MPI_COMM_WORLD);
    stuff=(double *)malloc(nmax*sizeof(double));

    offset=8*rank*nmax;
    MPI_File_open(MPI_COMM_WORLD, "/tmp/c.10", MPI_MODE_RDONLY, MPI_INFO_NULL, &handle);
    MPI_File_seek(handle, offset, MPI_SEEK_SET);
    MPI_File_read(handle, stuff, nmax, MPI_DOUBLE, &status);
    MPI_File_close(&handle);

    if (rank==0){
	clock_gettime(CLOCK_REALTIME,&t2);
	printf("Time for reading data = %f\n",(double)(t2.tv_sec-t1.tv_sec)+(double)(t2.tv_nsec-t1.tv_nsec)/BILLION);
    }
    /* Compute average and standard deviation (parallel) */
    ndata=size*nmax;
    compute(stuff,nmax,&average,&standard,ndata,rank);
    if (rank==0){
	printf("Average = %lf\n",average);
	printf("Standard Deviation = %lf\n",standard);
        clock_gettime(CLOCK_REALTIME,&t1);
	printf(" Time for computation = %f\n",(double)(t1.tv_sec-t2.tv_sec)+(double)(t1.tv_nsec-t2.tv_nsec)/BILLION);
    }
    free(stuff);
    MPI_Finalize();
    exit(0);
}
