#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <malloc.h>
#include <time.h>
#include "mpi.h"

void compute(double *array, long array_size, double *ave, double *std, long tot, int r){
    double sum,diff;
    int i;
    /* Compute average and standard deviation (parallel) */
    sum=0;
    *ave=0;
    *std=0;
    for (i=0;i<array_size;i++) sum+=array[i];
    MPI_Reduce(&sum,ave,1,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);
    if (r==0) *ave=*ave/(double)tot;
    MPI_Bcast(ave,1,MPI_DOUBLE,0,MPI_COMM_WORLD);
    sum=0;
    for (i=0;i<array_size;i++) {
	diff=array[i] - *ave;
	sum+=diff*diff;
    }
    MPI_Reduce(&sum,std,1,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);
    if (r==0) *std=sqrt((float) *std/tot);
    return;
}
