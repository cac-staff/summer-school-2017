#include <stdlib.h>
#include <math.h>

void Random(double *array,long array_size,int r){
    int j;
    srand(13276+47*r);
    /* Squaring the random number to increase accuracy */
    for (j=0;j<array_size;j++){array[j]=
	    (double)((long)RAND_MAX*rand()+rand()) /
	    ((double)(long)RAND_MAX * (double)((long)RAND_MAX+1));
    }
    return;
}

