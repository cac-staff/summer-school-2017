/*
! Example 3 of the MPI course. It performs parallelized 
! calculation of the multiplication of  
!     matrix A with matrix B.
! HPCVL, Queen's University, 2006
*/


#include "mpi.h"
#include <stdio.h>
#include <malloc.h>


int myid, totps, matrixsize[3], ibeginning, iending, averagelenth, reallenth, i, j, k, l;
float *ma, *mb, *mc, *mp;
int ma_col, mb_col, mc_col, mp_col;
FILE * fin, * fout;


void InitialMPI(int *myid, int *totps);
void MatrixInitialize();
void Demo03();




int main(argc,argv)
int argc;
char *argv[];
{
  MPI_Init(&argc,&argv);
  InitialMPI(&myid, &totps);
  MatrixInitialize();
  Demo03();
  printf(" Process %d of %d done\n", myid, totps);
  MPI_Finalize();
}




void InitialMPI(int *myid, int *totps)
{
  MPI_Comm_rank(MPI_COMM_WORLD, myid);
  MPI_Comm_size(MPI_COMM_WORLD, totps);
}




void MatrixInitialize()
{
  if(myid == 0) {
  fin=fopen("in.dat","r");
  fscanf(fin,"%d %d %d", &matrixsize[2], &matrixsize[1], &matrixsize[0]);}
  
  MPI_Bcast(matrixsize, 3, MPI_INT, 0, MPI_COMM_WORLD);
  
  averagelenth=(matrixsize[2]-1)/totps+1;
  ibeginning=myid*averagelenth;
  iending=ibeginning+averagelenth; if(iending>matrixsize[2]) iending=matrixsize[2];

  ma=(float *)malloc(matrixsize[2]*matrixsize[1]*sizeof(float));
  if(myid == 0) for(i=0;i<matrixsize[2];i++)
                   {ma_col= i*matrixsize[1];
                    for(j=0;j<matrixsize[1];j++) fscanf(fin,"%f ",&ma[ma_col+j]);}
  MPI_Bcast(ma, matrixsize[2]*matrixsize[1], MPI_FLOAT, 0, MPI_COMM_WORLD);

  mb=(float *)malloc(matrixsize[1]*matrixsize[0]*sizeof(float));
  if(myid == 0) for(i=0;i<matrixsize[1];i++)for(j=0;j<matrixsize[0];j++)
                               fscanf(fin,"%f ",&mb[j*matrixsize[1]+i]);
  MPI_Bcast(mb, matrixsize[1]*matrixsize[0], MPI_FLOAT, 0, MPI_COMM_WORLD);

  mc=(float *)malloc(matrixsize[2]*matrixsize[0]*sizeof(float));

  mp=(float *)malloc(matrixsize[2]*matrixsize[0]*sizeof(float));
  
  if(myid == 0) fclose(fin);
}




void Demo03()
{ int jj;
  for(i=0;i<matrixsize[2];i++)
     {mp_col= i*matrixsize[0];
      for(j=0;j<matrixsize[0];j++) mp[mp_col+j]=0.0; }

  for(i=ibeginning;i<iending;i++) 
     {mp_col= i*matrixsize[0];
      ma_col= i*matrixsize[1];
      for(j=0;j<matrixsize[0];j++) 
         {jj=mp_col+j;
          mb_col= j*matrixsize[1];
          for(k=0;k<matrixsize[1];k++) 
              mp[jj]=mp[jj]+ma[ma_col+k]*mb[mb_col+k];
         }
     }
  
  for(i=0;i<matrixsize[2];i++)
     {mc_col= i*matrixsize[0];
      for(j=0;j<matrixsize[0];j++) mc[mc_col+j]=0.0; }
  MPI_Reduce(mp,mc,matrixsize[2]*matrixsize[0],MPI_FLOAT,MPI_SUM,0,MPI_COMM_WORLD);
  
  if(myid == 0) {
     fout=fopen("out.dat","w");
        for(i=0;i<matrixsize[2];i++)  
           {mc_col=i*matrixsize[0];
            for(j=0;j<matrixsize[0];j++) 
	        fprintf(fout,"%f %s",mc[mc_col+j]," ");fprintf(fout,"\n");}
     fclose(fout);}

  free(ma); free(mb); free(mc); free(mp);
}
