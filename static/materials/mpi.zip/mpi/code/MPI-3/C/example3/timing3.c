#include "mpi.h"
#include <stdio.h>
#include <malloc.h>
#include <math.h>
#include <time.h>

#define BILLION 1000000000L

int myid, totps, matrixsize[3], ibeginning, iending, averagelenth, reallenth, i, j, k, l;
float *ma, *mb, *mc, *mp, oosm;
int ma_col, mb_col, mc_col, mp_col;
struct timespec t1,t2;

FILE * fin, * fout;

void InitialMPI(int *myid, int *totps);
void MatrixInitialize();
void Demo03();
void setmat(int iset);

int main(argc,argv)
int argc;
char *argv[];
{
    if (myid == 0) clock_gettime(CLOCK_REALTIME,&t1);

    MPI_Init(&argc,&argv);
    InitialMPI(&myid, &totps);
    MatrixInitialize();
    if (myid == 0){ 
        clock_gettime(CLOCK_REALTIME,&t2);
        printf("Initialization time on rank 0 : %6.3f\n",
           (double)(t2.tv_sec-t1.tv_sec)+(double)(t2.tv_nsec-t1.tv_nsec)/BILLION);
    }
    Demo03();
    if (myid == 0){ 
        clock_gettime(CLOCK_REALTIME,&t1);
        printf("Computation time on rank 0 : %6.3f\n",
           (double)(t1.tv_sec-t2.tv_sec)+(double)(t1.tv_nsec-t2.tv_nsec)/BILLION);
    }
    MPI_Finalize();
    return(0);
}

void InitialMPI(int *myid, int *totps)
{
  MPI_Comm_rank(MPI_COMM_WORLD, myid);
  MPI_Comm_size(MPI_COMM_WORLD, totps);
  return;
}

void MatrixInitialize()
{
  if(myid == 0) {
  fin=fopen("dim.dat","r");
  fscanf(fin,"%d %d %d", &matrixsize[2], &matrixsize[1], &matrixsize[0]);
  fclose(fin);
  oosm=(float)1/sqrt((float)matrixsize[1]);}
  
  MPI_Bcast(matrixsize, 3, MPI_INT, 0, MPI_COMM_WORLD);
  
  averagelenth=(matrixsize[2]-1)/totps+1;
  ibeginning=myid*averagelenth;
  iending=ibeginning+averagelenth; if(iending>matrixsize[2]) iending=matrixsize[2];

  ma=(float *)malloc(matrixsize[2]*matrixsize[1]*sizeof(float));
  if(myid == 0) setmat(1);
  MPI_Bcast(ma, matrixsize[2]*matrixsize[1], MPI_FLOAT, 0, MPI_COMM_WORLD);

  mb=(float *)malloc(matrixsize[1]*matrixsize[0]*sizeof(float));
  if(myid == 0) setmat(2);
  MPI_Bcast(mb, matrixsize[1]*matrixsize[0], MPI_FLOAT, 0, MPI_COMM_WORLD);

  mc=(float *)malloc(matrixsize[2]*matrixsize[0]*sizeof(float));
  mp=(float *)malloc(matrixsize[2]*matrixsize[0]*sizeof(float));
  
  return;
}

void Demo03()
{
    int jj;
    
    for(i=0;i<matrixsize[2];i++)
	{mp_col= i*matrixsize[0];
	    for(j=0;j<matrixsize[0];j++) mp[mp_col+j]=0.0; }

    for(i=ibeginning;i<iending;i++) 
	{mp_col= i*matrixsize[0];
	    ma_col= i*matrixsize[1];
	    for(j=0;j<matrixsize[0];j++){
		jj=mp_col+j;
		mb_col=j*matrixsize[1];  
		for(k=0;k<matrixsize[1];k++) mp[jj]=mp[jj]+ma[ma_col+k]*mb[mb_col+k];
	    }
	}
    
    for(i=0;i<matrixsize[2];i++)
	{mc_col= i*matrixsize[0];
	    for(j=0;j<matrixsize[0];j++) mc[mc_col+j]=0.0; }
    MPI_Reduce(mp,mc,matrixsize[2]*matrixsize[0],MPI_FLOAT,MPI_SUM,0,MPI_COMM_WORLD);
    
    /** if(myid == 0) {for(i=0;i<matrixsize[2];i++) {mc_col=i*matrixsize[0];
	for(j=0;j<matrixsize[0];j++) printf("%f %s",mc[mc_col+j]," ");printf("\n");}} **/
    
    free(ma); free(mb); free(mc); free(mp);
    return;
}

void setmat(int iset)
{
    int i;
    if (iset == 1) for (i=0;i<matrixsize[2]*matrixsize[1];i++) ma[i] = oosm;
    else if (iset == 2) for (i=0;i<matrixsize[1]*matrixsize[0];i++) mb[i] = oosm;
    else printf("Iset %d not supported \n",iset);
    return;
}
       
