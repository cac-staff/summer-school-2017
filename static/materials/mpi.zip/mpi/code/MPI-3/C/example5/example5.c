/*
! Example 5 of the MPI course. It does the same 
! calculation as that of the example 3, but it 
! will reduce much memory. Or the memory of 
! some matrixes are distributed. Also in this  
! example, we use MPI_SCATTERV and MPI_GATHERV
! collective communications to replace the
! point-to-point communications in example 4.
! HPCVL, Queen's University, 2006
*/


#include "mpi.h"
#include <stdio.h>
#include <malloc.h>


int myid, totps, matrixsize[3], averagelenth,  i, j, k, l;
int *ibeginning, *iending, *reallenth;
float *ma, *mb, *mc, *mp;
int ma_col,mb_col,mc_col,mp_col;


void InitialMPI(int *myid, int *totps);
void MatrixInitialize();
void Distribute();
void Demo05();

int main(argc,argv)
int argc;
char *argv[];
{
  MPI_Init(&argc,&argv);
  InitialMPI(&myid, &totps);
  MatrixInitialize();
  Demo05();
  printf(" Process %d of %d done\n", myid, totps);
  MPI_Finalize();
  return(0);
}

void InitialMPI(int *myid, int *totps)
{
  MPI_Comm_rank(MPI_COMM_WORLD, myid);
  MPI_Comm_size(MPI_COMM_WORLD, totps);
  return;
}




void Distribute()
{
  ibeginning=(int *)malloc(totps*sizeof(int));
  iending=   (int *)malloc(totps*sizeof(int));
  reallenth= (int *)malloc(totps*sizeof(int));

  averagelenth=(matrixsize[2]-1)/totps+1;

  for(i=0;i<totps;i++)
     { ibeginning[i]=i*averagelenth;
       iending[i]=ibeginning[i]+averagelenth;
       if(iending[i]>matrixsize[2]) iending[i]=matrixsize[2];
       reallenth[i]=iending[i]-ibeginning[i];
       if(reallenth[i]<0) reallenth[i]=0;
     };
  return;
}




void MatrixInitialize()
{
  FILE  * fin;
  int mpitag=1;    
  MPI_Status anmpistatus;

  if(myid == 0) {
  fin=fopen("in.dat","r");
  fscanf(fin,"%d %d %d", &matrixsize[2], &matrixsize[1], &matrixsize[0]);}
  
  MPI_Bcast(matrixsize, 3, MPI_INT, 0, MPI_COMM_WORLD);
  
  Distribute();

  ma=(float *)malloc(reallenth[myid]*matrixsize[1]*sizeof(float));
  
  if(myid == 0) 
    {
      mc=(float *)malloc(matrixsize[2]*matrixsize[1]*sizeof(float));
      for(i=0;i<matrixsize[2];i++)for(j=0;j<matrixsize[1];j++) 
                     fscanf(fin,"%f ",&mc[i*matrixsize[1]+j]);
    }

  int * sendcnts; sendcnts=  (int *) malloc(totps*sizeof(int));
  int * rcvdplts; rcvdplts=  (int *) malloc(totps*sizeof(int));
  for(i=0;i<totps;i++) sendcnts[i]= reallenth[i]*matrixsize[1];
  for(i=0;i<totps;i++) rcvdplts[i]=ibeginning[i]*matrixsize[1];

  MPI_Scatterv(mc,sendcnts,rcvdplts,MPI_FLOAT,
               ma,reallenth[myid]*matrixsize[1],MPI_FLOAT,0,MPI_COMM_WORLD);

  if(myid == 0) free(mc); 
    
  mb=(float *)malloc(matrixsize[1]*matrixsize[0]*sizeof(float));
  if(myid == 0) for(i=0;i<matrixsize[1];i++)for(j=0;j<matrixsize[0];j++) 
                               fscanf(fin,"%f ",&mb[j*matrixsize[1]+i]); 
  MPI_Bcast(mb, matrixsize[1]*matrixsize[0], MPI_FLOAT, 0, MPI_COMM_WORLD);

  mp=(float *)malloc(reallenth[myid]*matrixsize[0]*sizeof(float));
  
  if(myid == 0) fclose(fin);
  free(sendcnts); free(rcvdplts);
  return;
}




void Demo05()
{
  FILE * fout;
  int mpitag=1;    
  MPI_Status anmpistatus;
  int jj;    

  for(i=0;i<reallenth[myid];i++)
     {mp_col= i*matrixsize[0];
      ma_col= i*matrixsize[1];
      for(j=0;j<matrixsize[0];j++) 
        { jj=mp_col+j;
          mp[jj]=0.0; 
          mb_col= j*matrixsize[1];
	  for(k=0;k<matrixsize[1];k++) 
              mp[jj]=mp[jj]+ma[ma_col+k]*mb[mb_col+k];
        }
     }
  
  if(myid == 0) 
    {
      mc=(float *)malloc(matrixsize[2]*matrixsize[0]*sizeof(float));
      for(i=0;i<matrixsize[2];i++)
         {mc_col= i*matrixsize[0];
          for(j=0;j<matrixsize[0];j++)mc[mc_col+j]=0.0;
         }
    }

  int * rcvcnts; rcvcnts=   (int *) malloc(totps*sizeof(int));
  int * rcvdplt; rcvdplt=   (int *) malloc(totps*sizeof(int));
  for(i=0;i<totps;i++) rcvcnts[i]= reallenth[i]*matrixsize[0];
  for(i=0;i<totps;i++) rcvdplt[i]=ibeginning[i]*matrixsize[0];

  MPI_Gatherv(mp,reallenth[myid]*matrixsize[0],MPI_FLOAT,mc,
                 rcvcnts,rcvdplt,MPI_FLOAT,0,MPI_COMM_WORLD);

  if(myid == 0) 
    {
      fout=fopen("out.dat","w");
        for(i=0;i<matrixsize[2];i++) {
            for(j=0;j<matrixsize[0];j++) 
	        fprintf(fout,"%f %s",mc[i*matrixsize[0]+j]," ");
                                             fprintf(fout,"\n");}
      fclose(fout);
      free(mc);
    }

  free(ma); free(mb); free(mp); 
  free(rcvcnts); free(rcvdplt);
  free(ibeginning);free(iending);free(reallenth);

  return;
}
