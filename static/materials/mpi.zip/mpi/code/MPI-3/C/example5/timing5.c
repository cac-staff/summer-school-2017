#include "mpi.h"
#include <stdio.h>
#include <malloc.h>
#include <math.h>
#include <time.h>

#define BILLION 1000000000L

int myid, totps, matrixsize[3], averagelenth,  i, j, k, l;
int *ibeginning, *iending, *reallenth;
float *ma, *mb, *mc, *mp, oosm;
int ma_col,mb_col,mc_col,mp_col;
struct timespec t1,t2;

void InitialMPI(int *myid, int *totps);
void MatrixInitialize();
void Distribute();
void Demo05();
void setmat(int iset);

int main(argc,argv)
int argc;
char *argv[];
{
    if (myid == 0) clock_gettime(CLOCK_REALTIME,&t1);

    MPI_Init(&argc,&argv);
    InitialMPI(&myid, &totps);
    MatrixInitialize();
    if (myid == 0){
        clock_gettime(CLOCK_REALTIME,&t2);
        printf("Initialization time on rank 0 : %6.3f\n",
           (double)(t2.tv_sec-t1.tv_sec)+(double)(t2.tv_nsec-t1.tv_nsec)/BILLION);
    }

    Demo05();
    if (myid == 0){
        clock_gettime(CLOCK_REALTIME,&t1);
        printf("Computation time on rank 0 : %6.3f\n",
           (double)(t1.tv_sec-t2.tv_sec)+(double)(t1.tv_nsec-t2.tv_nsec)/BILLION);
    }

    MPI_Finalize(); 
    return(0);
}

void InitialMPI(int *myid, int *totps)
{
  MPI_Comm_rank(MPI_COMM_WORLD, myid);
  MPI_Comm_size(MPI_COMM_WORLD, totps);
  return;
}

void Distribute()
{
  ibeginning=(int *)malloc(totps*sizeof(int));
  iending=   (int *)malloc(totps*sizeof(int));
  reallenth= (int *)malloc(totps*sizeof(int));

  averagelenth=(matrixsize[2]-1)/totps+1;

  for(i=0;i<totps;i++)
     { ibeginning[i]=i*averagelenth;
       iending[i]=ibeginning[i]+averagelenth;
       if(iending[i]>matrixsize[2]) iending[i]=matrixsize[2];
       reallenth[i]=iending[i]-ibeginning[i];
       if(reallenth[i]<0) reallenth[i]=0;
     };
  return;
}

void MatrixInitialize()
{
    FILE  * fin;
    int mpitag=1;    
    MPI_Status anmpistatus;
    
    if(myid == 0) {
	fin=fopen("dim.dat","r");
	fscanf(fin,"%d %d %d", &matrixsize[2], &matrixsize[1], &matrixsize[0]);
	fclose(fin);
	oosm=1/sqrt((float)matrixsize[1]);
    }

    MPI_Bcast(matrixsize, 3, MPI_INT, 0, MPI_COMM_WORLD);
    
    Distribute();
    
    ma=(float *)malloc(reallenth[myid]*matrixsize[1]*sizeof(float));

    if(myid == 0){
	mc=(float *)malloc(matrixsize[2]*matrixsize[1]*sizeof(float));
	setmat(3);
    }

    int * sendcnts; sendcnts=  (int *) malloc(totps*sizeof(int));
    int * rcvdplts; rcvdplts=  (int *) malloc(totps*sizeof(int));
    for(i=0;i<totps;i++) sendcnts[i]= reallenth[i]*matrixsize[1];
    for(i=0;i<totps;i++) rcvdplts[i]=ibeginning[i]*matrixsize[1];
    MPI_Scatterv(mc,sendcnts,rcvdplts,MPI_FLOAT,
		 ma,reallenth[myid]*matrixsize[1],MPI_FLOAT,0,MPI_COMM_WORLD);
    
    if(myid == 0) free(mc); 
    
    mb=(float *)malloc(matrixsize[1]*matrixsize[0]*sizeof(float));
    if(myid == 0) setmat(2);

    MPI_Bcast(mb, matrixsize[1]*matrixsize[0], MPI_FLOAT, 0, MPI_COMM_WORLD);
    mp=(float *)malloc(reallenth[myid]*matrixsize[0]*sizeof(float));
    
    free(sendcnts); free(rcvdplts);
  return;
}

void Demo05()
{
  FILE * fout;
  int mpitag=1;    
  MPI_Status anmpistatus;
  int jj;    

  for(i=0;i<reallenth[myid];i++)
     {mp_col= i*matrixsize[0];
      ma_col= i*matrixsize[1];
      for(j=0;j<matrixsize[0];j++) 
        { jj=mp_col+j;
          mp[jj]=0.0; 
          mb_col= j*matrixsize[1];
	  for(k=0;k<matrixsize[1];k++) 
              mp[jj]=mp[jj]+ma[ma_col+k]*mb[mb_col+k];
        }
     }
  
  if(myid == 0) 
    {
      mc=(float *)malloc(matrixsize[2]*matrixsize[0]*sizeof(float));
      for(i=0;i<matrixsize[2];i++)
         {mc_col= i*matrixsize[0];
          for(j=0;j<matrixsize[0];j++)mc[mc_col+j]=0.0;
         }
    }

  int * rcvcnts; rcvcnts=   (int *) malloc(totps*sizeof(int));
  int * rcvdplt; rcvdplt=   (int *) malloc(totps*sizeof(int));
  for(i=0;i<totps;i++) rcvcnts[i]= reallenth[i]*matrixsize[0];
  for(i=0;i<totps;i++) rcvdplt[i]=ibeginning[i]*matrixsize[0];

  MPI_Gatherv(mp,reallenth[myid]*matrixsize[0],MPI_FLOAT,mc,
                 rcvcnts,rcvdplt,MPI_FLOAT,0,MPI_COMM_WORLD);

  /** if(myid == 0){for(i=0;i<matrixsize[2];i++){for(j=0;j<matrixsize[0];j++) 
      printf("%f %s",mc[i*matrixsize[0]+j]," ");printf("\n");}} **/
  
  if(myid==0) free(mc);
  free(ma); free(mb); free(mp); 
  free(rcvcnts); free(rcvdplt);
  free(ibeginning);free(iending);free(reallenth);

  return;
}

void setmat(int iset)
{
  int i;
  if (iset == 2) for (i=0;i<matrixsize[0]*matrixsize[1];i++) mb[i] = oosm;
  else if (iset == 3) for (i=0;i<matrixsize[1]*matrixsize[2];i++) mc[i] = oosm;
  else printf("Iset %d not supported \n",iset);
  return;
} 
