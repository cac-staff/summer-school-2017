/*
C    This is an example code to split a communicator 
C    into a few smaller ones.
C    HPCVL, Queen's University, October, 2004
*/


#include <mpi.h>
#include <math.h>
#include <stdio.h>




int main(argc,argv)
int argc;
char *argv[];
{
  int MyID, TotalPS, i, Sum1=0, Sum2=0;
  int NumOfComm, NumOfProcessPerNewComm, NewMyID, NewTotalPS;
  MPI_Comm NewComm;
  
  MPI_Init(&argc,&argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &MyID);
  MPI_Comm_size(MPI_COMM_WORLD, &TotalPS);
  
  for(i=1;i<=(int)sqrt((float)(TotalPS+1));i++) 
      if((TotalPS/i)*i==TotalPS)   NumOfComm=i;
  NumOfProcessPerNewComm=TotalPS/NumOfComm;

  MPI_Comm_split(MPI_COMM_WORLD, 
      MyID/NumOfProcessPerNewComm, MyID, &NewComm);

  MPI_Comm_rank(NewComm, &NewMyID);
  MPI_Comm_size(NewComm, &NewTotalPS);

  MPI_Allreduce(&MyID,&Sum2,1,MPI_INT,MPI_SUM,NewComm);
  MPI_Allreduce(&MyID,&Sum1,1,MPI_INT,MPI_SUM,MPI_COMM_WORLD);
  
  if(MyID == 0) printf("NewID, OldID, Sum2, Sum1, NewTotalPS, OldTotalPS \n\n");
  MPI_Barrier(MPI_COMM_WORLD);
  printf("%5d %6d %5d %5d %11d %11d \n", NewMyID, MyID, Sum2, Sum1, NewTotalPS, TotalPS);
 
  MPI_Comm_free(&NewComm);
  MPI_Finalize();
}
