/*
C    This is an example code for the Master-Slave 
C    Parallel Model.
C    HPCVL, Queen.s University, October, 2011
*/

#include <mpi.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>

int rand(void);
int sleep(int);

int MyID, TotalPS, Master, NumOfJobs;
int *JobIDid, *SumIDid, *JobAssignedByMaster;
int *TotalIDid, *SumTotalIDid, *TotalAssigned;
int *TimesNoMoreWorkIReceived; 
int *SumTimesNoMoreWorkIReceived;
int *TImesNoMoreWorkInstructed;
int i;

void InitialMPI(int *MyID, int *totps);
void MasterSlaveModelInitialize();
void MasterSlaveModel();
void MasterSlaveModelFinalize();
void DoOneJob(int jobnumber, int myslavenumber);
void load();
int work[20];

int main(argc,argv)
int argc;
char *argv[];
{
  MPI_Init(&argc,&argv);
  InitialMPI(&MyID, &TotalPS);
  MasterSlaveModelInitialize();
  MasterSlaveModel();
  MasterSlaveModelFinalize();
  MPI_Finalize();
}

void InitialMPI(int *MyID, int *totps)
{
  MPI_Comm_rank(MPI_COMM_WORLD, MyID);
  MPI_Comm_size(MPI_COMM_WORLD, totps);
}

void MasterSlaveModelInitialize()
{
  Master=0;
  load();
  if(MyID==Master) 
      { NumOfJobs=20;
      printf("%d \n",NumOfJobs);
    }
  MPI_Bcast(&NumOfJobs, 1, MPI_INT, 
                    Master, MPI_COMM_WORLD);
  if(NumOfJobs<1)
     {printf( "Error for Number of Jobs: %d " , 
                                    NumOfJobs);
      printf( " in MasterSlaveModelInitialize().\n") ;
      MPI_Finalize(); 
      exit(0);
     }

  if(TotalPS<2)
     {printf( "Error for Number of Processes: %d" , TotalPS);
      printf( " in MasterSlaveModelInitialize().\n" );
      MPI_Finalize(); 
      exit(0);
     }

  if((JobIDid=(int *) 
      malloc((NumOfJobs+1)*sizeof(int)))==NULL) 
     {printf( "Error on memory allocation in MasterSlaveModelInitialize().\n") ;
      MPI_Finalize(); 
      exit(0);
     }

  if((SumIDid=(int *) 
      malloc((NumOfJobs+1)*sizeof(int)))==NULL) 
     {printf( "Error on memory allocation in MasterSlaveModelInitialize().\n") ;
      MPI_Finalize(); 
      exit(0);
      }

  if((JobAssignedByMaster=
      malloc((NumOfJobs+1)*sizeof(int)))==NULL) 
     {printf( "Error on memory allocation in MasterSlaveModelInitialize().\n") ;
      MPI_Finalize(); 
      exit(0);
     }

  if((TotalIDid=(int *) 
      malloc(TotalPS*sizeof(int)))==NULL) 
     {printf( "Error on memory allocation in MasterSlaveModelInitialize().\n") ;
      MPI_Finalize(); 
      exit(0);
     }

  if((SumTotalIDid=(int *) 
      malloc(TotalPS*sizeof(int)))==NULL) 
     {printf( "Error on memory allocation in MasterSlaveModelInitialize().\n") ;
      MPI_Finalize(); 
      exit(0);
     }

  if((TotalAssigned=(int *) 
      malloc(TotalPS*sizeof(int)))==NULL) 
     {printf( "Error on memory allocation in MasterSlaveModelInitialize().\n") ;
      MPI_Finalize(); 
      exit(0);
      }

  if((TimesNoMoreWorkIReceived=(int *) 
      malloc(TotalPS*sizeof(int)))==NULL) 
     {printf( "Error on memory allocation in MasterSlaveModelInitialize().\n") ;
      MPI_Finalize(); 
      exit(0);
     }

  if((SumTimesNoMoreWorkIReceived=(int *) 
      malloc(TotalPS*sizeof(int)))==NULL) 
     {printf( "Error on memory allocation in MasterSlaveModelInitialize().\n") ;
      MPI_Finalize(); 
      exit(0);
     }

  if((TImesNoMoreWorkInstructed=(int *) 
      malloc(TotalPS*sizeof(int)))==NULL) 
     {printf( "Error on memory allocation in MasterSlaveModelInitialize().\n") ;
      MPI_Finalize(); 
      exit(0);
     }

  for(i=0;i<=NumOfJobs;i++)       JobIDid[i]=0;
  for(i=0;i<=NumOfJobs;i++)       SumIDid[i]=0;
  for(i=0;i<=NumOfJobs;i++) 
                     JobAssignedByMaster[i]=-1;
  for(i=0;i<TotalPS;i++)        TotalIDid[i]=0;
  for(i=0;i<TotalPS;i++)     SumTotalIDid[i]=0;
  for(i=0;i<TotalPS;i++)    TotalAssigned[i]=0;
  for(i=0;i<TotalPS;i++)     
                 TimesNoMoreWorkIReceived[i]=0;
  for(i=0;i<TotalPS;i++)    
              SumTimesNoMoreWorkIReceived[i]=0;
  for(i=0;i<TotalPS;i++)    
                TImesNoMoreWorkInstructed[i]=0;

}




void MasterSlaveModel()
{
  int mpitag=1, received, repeat;    
  MPI_Status anmpistatus;
       
  if(MyID != Master) 
    {
      repeat=1;
      while (repeat ==1) 
       {
         MPI_Send(&MyID,1, MPI_INT,Master, 
                  mpitag+MyID, MPI_COMM_WORLD);
         printf("Slave # %4d reports to Master he's idle.\n", MyID);

         MPI_Recv(&received,1,MPI_INT,Master , 
                  mpitag+MyID, MPI_COMM_WORLD, 
                                 &anmpistatus);
         if (received <= NumOfJobs)
	        {
              DoOneJob(received, MyID);
              printf("Slave # %4d received job # %4d .\n",MyID,received);
              JobIDid[received]=MyID;
	           (TotalIDid[MyID])++;
	        }
         else
	        {
              printf("Slave # %4d received no more job instruction.\n",MyID);
	           (TimesNoMoreWorkIReceived[MyID])++;
	           repeat=0;
	        }
        }
    }
  
 else
  
    { 
     for(i=1;i<NumOfJobs+TotalPS;i++) 
        {
         MPI_Recv(&received,1,MPI_INT,          
                  MPI_ANY_SOURCE, MPI_ANY_TAG,  
                  MPI_COMM_WORLD, &anmpistatus);
	      MPI_Send(&i,1,MPI_INT,received, 
                  mpitag+received, 
                  MPI_COMM_WORLD);

	      if(i<= NumOfJobs)
	        {
	         printf("Master assigned job # %4d to slave # %4d .\n",i,received);  
	         JobAssignedByMaster[i]=received;
	         (TotalAssigned[received])++;
	        }
         else
	        {printf("Master informed slave # %4d no more jobs. \n",received);
            (TImesNoMoreWorkInstructed[received])++;
	        }
	     }
    }
}




void MasterSlaveModelFinalize()
{
  MPI_Reduce(JobIDid, SumIDid, NumOfJobs+1, MPI_INT, MPI_SUM,        
                                      Master,MPI_COMM_WORLD);
  MPI_Reduce(TotalIDid, SumTotalIDid, TotalPS, MPI_INT, MPI_SUM, 
                                         Master,MPI_COMM_WORLD);
  MPI_Reduce(TimesNoMoreWorkIReceived, SumTimesNoMoreWorkIReceived, 
                  TotalPS, MPI_INT, MPI_SUM,Master,MPI_COMM_WORLD); 
  if(MyID == Master) 
     {
        FILE * fout;
        fout=fopen("msm.out","w");
        fprintf(fout,"Master-Slave model performed. \n" )  ;
	   fprintf(fout,"Total number of jobs      : %d .\n" , NumOfJobs)   ;
	   fprintf(fout,"Total number of processes : %d, " ,TotalPS);
	   fprintf(fout,"  of which %d are slaves, " , TotalPS-1 );
	   fprintf(fout," while Rank %d is master. \n", Master ) ;
	   fprintf(fout, "\n");
	   fprintf(fout,"Job           number: "); 
        for(i=1;i<=NumOfJobs;i++) 
	   fprintf(fout, "%4d ", i);
	   fprintf(fout, "\n");
	   fprintf(fout, "Assigned  to slave #: ") ;
        for(i=1;i<=NumOfJobs;i++) 
	   fprintf(fout, "%4d ",JobAssignedByMaster[i]);
	   fprintf(fout, "\n");
	   fprintf(fout,"Completed by slave #: " );
        for(i=1;i<=NumOfJobs;i++) 
	   fprintf(fout, "%4d ",SumIDid[i]);
	   fprintf(fout, "\n");
	   fprintf(fout, "\n");
	   fprintf(fout,"Process                         number: ") ; 
        for(i=0;i<=TotalPS-1;i++) 
	   fprintf(fout, "%4d ", i);
	   fprintf(fout, "\n");
	   fprintf(fout,"Total number of jobs  assigned to each: " ); 
        for(i=0;i<=TotalPS-1;i++) 
	   fprintf(fout, "%4d ",TotalAssigned[i]);
	   fprintf(fout, "\n");
	   fprintf(fout,"Total number of jobs completed by each: " ); 
        for(i=0;i<=TotalPS-1;i++) 
	   fprintf(fout, "%4d ",SumTotalIDid[i]);
	   fprintf(fout, "\n");
	   fprintf(fout, "\n");
	   fprintf(fout, "Process                         number: " ); 
        for(i=0;i<=TotalPS-1;i++) 
	   fprintf(fout, "%4d ", i);
	   fprintf(fout, "\n");
	   fprintf(fout, "Times sent,  for no more job,  to each: " ); 
        for(i=0;i<=TotalPS-1;i++) 
	   fprintf(fout, "%4d ",TImesNoMoreWorkInstructed[i]);
	   fprintf(fout, "\n");
	   fprintf(fout, "Times received for no more job by each: " ); 
        for(i=0;i<=TotalPS-1;i++) 
	   fprintf(fout, "%4d ",SumTimesNoMoreWorkIReceived[i]);
	   fprintf(fout, "\n");
	   fprintf(fout, "\n");
        fprintf(fout, "End of Master-Slave model report. \n") ;
        fclose(fout);
     
     }

  free(JobIDid);
  free(SumIDid);
  free(JobAssignedByMaster);
  free(TotalIDid);
  free(SumTotalIDid);
  free(TotalAssigned);
  free(TimesNoMoreWorkIReceived);
  free(SumTimesNoMoreWorkIReceived);
  free(TImesNoMoreWorkInstructed);
}

void DoOneJob(int jobnumber, int myslavenumber){
    int st=work[jobnumber-1];
    sleep(st);
    printf(" Job number %d done by process number %d, slept for %d secs.\n", 
	   jobnumber, myslavenumber, st);
    return;
}

void load(){
    int i,randnum;
    for (i=0;i<20;i++){
        randnum=rand();
	work[i]=randnum-(randnum/5)*5+1;
    }
}

