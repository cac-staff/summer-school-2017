#include "stdio.h"
#include "mpi.h"

void initialmpi(int *myid, int *totps);

int main(argc,argv)
int argc;
char *argv[];
{int myid,totps;
MPI_Init(&argc,&argv);
initialmpi(&myid, &totps);
printf ("Hello from rank: %d of total %d processes.\n",myid,totps);
MPI_Finalize();
}

void initialmpi(int *myid, int *totps){
MPI_Comm_rank(MPI_COMM_WORLD, myid);
MPI_Comm_size(MPI_COMM_WORLD, totps);}

